import { randomBytes, scrypt as scryptCb, timingSafeEqual, createHash } from "node:crypto";
import { promisify } from "node:util";
import { and, eq, gt, isNull } from "drizzle-orm";
import { db } from "../db/index.js";
import { admins, appState, auditLog, players, sessions } from "../db/schema.js";

const scrypt = promisify(scryptCb) as (pw: string, salt: Buffer, len: number) => Promise<Buffer>;

export const TICKET_PRICE = 100; // ₦100 = 1 ticket (fixed by policy)
export const MAX_TICKETS_PER_ORDER = 1000;
export const MAX_OPEN_ORDERS = 5;
export const MAX_PROOF_BYTES = 4 * 1024 * 1024; // keeps uploads under the function payload limit

export const DEFAULT_ACCOUNT = {
  accountNumber: "8022447576",
  bankName: "SmartCash PSB",
  accountName: "Abdulhameed Abdulkareem",
};

// Admin sessions expire after 2 hours without admin activity, and never live
// longer than 12 hours. Player sessions last 30 days.
export const ADMIN_IDLE_MS = 2 * 60 * 60 * 1000;
export const ADMIN_MAX_MS = 12 * 60 * 60 * 1000;
export const PLAYER_SESSION_MS = 30 * 24 * 60 * 60 * 1000;
const MAX_FAILED_LOGINS = 5;
const LOCK_MS = 15 * 60 * 1000;

export const ADMIN_COOKIE = "md_admin";
export const PLAYER_COOKIE = "md_player";

// ---------- HTTP helpers ----------

export class HttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export const fail = (status: number, message: string): never => {
  throw new HttpError(status, message);
};

export function json(data: unknown, status = 200, headers: HeadersInit = {}) {
  const h = new Headers(headers);
  h.set("content-type", "application/json");
  h.set("cache-control", "no-store");
  return new Response(JSON.stringify(data), { status, headers: h });
}

export function parseCookies(req: Request): Record<string, string> {
  const out: Record<string, string> = {};
  const raw = req.headers.get("cookie") || "";
  raw.split(";").forEach((part) => {
    const i = part.indexOf("=");
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  });
  return out;
}

function isSecure(req: Request) {
  return new URL(req.url).protocol === "https:";
}

export function sessionCookie(req: Request, name: string, token: string, maxAgeMs: number) {
  return `${name}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${Math.floor(maxAgeMs / 1000)}${isSecure(req) ? "; Secure" : ""}`;
}

export function clearCookie(req: Request, name: string) {
  return `${name}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${isSecure(req) ? "; Secure" : ""}`;
}

export async function readJson(req: Request): Promise<Record<string, any>> {
  try {
    const body = await req.json();
    return body && typeof body === "object" ? body : {};
  } catch {
    return {};
  }
}

// ---------- Validation ----------

export function intIn(value: unknown, min: number, max: number, label: string): number {
  const n = typeof value === "string" && value.trim() !== "" ? Number(value) : value;
  if (typeof n !== "number" || !Number.isInteger(n) || n < min || n > max) {
    fail(400, `${label} must be a whole number between ${min} and ${max}`);
  }
  return n as number;
}

export function str(value: unknown, label: string, { min = 0, max = 500 } = {}): string {
  const s = typeof value === "string" ? value.trim() : "";
  if (s.length < min) fail(400, min <= 1 ? `${label} is required` : `${label} must be at least ${min} characters`);
  if (s.length > max) fail(400, `${label} must be at most ${max} characters`);
  return s;
}

export function optDate(value: unknown, label: string): Date | null {
  if (value === null || value === undefined || value === "") return null;
  const d = new Date(String(value));
  if (isNaN(d.getTime())) fail(400, `${label} is not a valid date`);
  return d;
}

export function validPin(pin: unknown): string {
  const s = typeof pin === "string" ? pin.trim() : "";
  if (!/^\d{4,8}$/.test(s)) fail(400, "PIN must be 4 to 8 digits");
  return s;
}

export const nameKey = (name: string) => name.trim().toLowerCase().replace(/\s+/g, " ");

// ---------- Crypto ----------

export async function hashSecret(secret: string): Promise<string> {
  const salt = randomBytes(16);
  const hash = await scrypt(secret, salt, 32);
  return `scrypt$${salt.toString("hex")}$${hash.toString("hex")}`;
}

export async function verifySecret(secret: string, stored: string): Promise<boolean> {
  const [algo, saltHex, hashHex] = stored.split("$");
  if (algo !== "scrypt" || !saltHex || !hashHex) return false;
  const hash = await scrypt(secret, Buffer.from(saltHex, "hex"), 32);
  const expected = Buffer.from(hashHex, "hex");
  return expected.length === hash.length && timingSafeEqual(expected, hash);
}

export function safeEqual(a: string, b: string) {
  const ha = createHash("sha256").update(a).digest();
  const hb = createHash("sha256").update(b).digest();
  return timingSafeEqual(ha, hb);
}

const tokenHash = (token: string) => createHash("sha256").update(token).digest("hex");

export function randomRef(prefix: string) {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = randomBytes(8);
  let s = "";
  for (const b of bytes) s += alphabet[b % alphabet.length];
  return `${prefix}-${s}`;
}

// ---------- Sessions ----------

export async function createSession(kind: "admin" | "player", subjectId: number, ttlMs: number) {
  const token = randomBytes(32).toString("base64url");
  const [row] = await db
    .insert(sessions)
    .values({ tokenHash: tokenHash(token), kind, subjectId, expiresAt: new Date(Date.now() + ttlMs) })
    .returning();
  return { token, session: row };
}

async function findSession(req: Request, cookie: string, kind: "admin" | "player") {
  const token = parseCookies(req)[cookie];
  if (!token) return null;
  const [row] = await db
    .select()
    .from(sessions)
    .where(
      and(
        eq(sessions.tokenHash, tokenHash(token)),
        eq(sessions.kind, kind),
        isNull(sessions.revokedAt),
        gt(sessions.expiresAt, new Date()),
      ),
    );
  return row || null;
}

export async function revokeSession(req: Request, cookie: string, kind: "admin" | "player") {
  const s = await findSession(req, cookie, kind);
  if (s) await db.update(sessions).set({ revokedAt: new Date() }).where(eq(sessions.id, s.id));
  return s;
}

export type AdminCtx = { admin: typeof admins.$inferSelect; session: typeof sessions.$inferSelect };
export type PlayerCtx = { player: typeof players.$inferSelect; session: typeof sessions.$inferSelect };

/** Returns the signed-in admin, or null. When `touch` is set the idle timer is extended. */
export async function getAdmin(req: Request, touch = false): Promise<AdminCtx | null> {
  const session = await findSession(req, ADMIN_COOKIE, "admin");
  if (!session) return null;
  const [admin] = await db.select().from(admins).where(eq(admins.id, session.subjectId));
  if (!admin) return null;
  if (touch) {
    const cap = session.createdAt.getTime() + ADMIN_MAX_MS;
    const next = Math.min(Date.now() + ADMIN_IDLE_MS, cap);
    if (next - session.expiresAt.getTime() > 60_000) {
      await db.update(sessions).set({ expiresAt: new Date(next) }).where(eq(sessions.id, session.id));
      session.expiresAt = new Date(next);
    }
  }
  return { admin, session };
}

export async function requireAdmin(req: Request): Promise<AdminCtx> {
  const ctx = await getAdmin(req, true);
  if (!ctx) fail(401, "Administrator sign-in required (your session may have expired)");
  return ctx!;
}

export async function getPlayer(req: Request): Promise<PlayerCtx | null> {
  const session = await findSession(req, PLAYER_COOKIE, "player");
  if (!session) return null;
  const [player] = await db.select().from(players).where(eq(players.id, session.subjectId));
  if (!player) return null;
  return { player, session };
}

export async function requirePlayer(req: Request): Promise<PlayerCtx> {
  const ctx = await getPlayer(req);
  if (!ctx) fail(401, "Please sign in with your name and PIN");
  return ctx!;
}

export function lockedMessage(lockedUntil: Date | null) {
  if (lockedUntil && lockedUntil.getTime() > Date.now()) {
    const mins = Math.ceil((lockedUntil.getTime() - Date.now()) / 60000);
    return `Too many failed attempts. Try again in ${mins} minute${mins === 1 ? "" : "s"}.`;
  }
  return null;
}

export function nextFailure(failed: number) {
  const count = failed + 1;
  return count >= MAX_FAILED_LOGINS
    ? { failedLogins: 0, lockedUntil: new Date(Date.now() + LOCK_MS) }
    : { failedLogins: count };
}

// ---------- Player status policy ----------
//
// active    – full access: buy tickets, upload proofs, contribute, be marked
//             present, be drawn and (when the admin allows it) run the draw.
// suspended – can sign in and view all records; may finish proof uploads for
//             ticket orders placed before suspension and submit contribution
//             payments. Cannot buy new tickets, be marked present, be drawn or
//             run draws.
// disabled  – read-only: can sign in and view history only. No purchases,
//             uploads, contributions, presence or draws.

export const STATUS_POLICY = {
  active: { buy: true, uploadOrderProof: true, contribute: true, presence: true, draw: true },
  suspended: { buy: false, uploadOrderProof: true, contribute: true, presence: false, draw: false },
  disabled: { buy: false, uploadOrderProof: false, contribute: false, presence: false, draw: false },
} as const;

export type PlayerStatus = keyof typeof STATUS_POLICY;

export function can(player: { status: string }, action: keyof (typeof STATUS_POLICY)["active"]) {
  const policy = STATUS_POLICY[(player.status as PlayerStatus) in STATUS_POLICY ? (player.status as PlayerStatus) : "disabled"];
  return policy[action];
}

export function requireCan(player: { status: string; statusReason?: string | null }, action: keyof (typeof STATUS_POLICY)["active"]) {
  if (!can(player, action)) {
    const reason = player.statusReason ? ` Reason: ${player.statusReason}` : "";
    fail(403, `Your account is ${player.status}, so this action is not allowed.${reason}`);
  }
}

// ---------- App state ----------

export async function getState() {
  const [row] = await db.select().from(appState).where(eq(appState.id, 1));
  if (row) return row;
  await db
    .insert(appState)
    .values({ id: 1, ...DEFAULT_ACCOUNT, assignments: { 1: [], 2: [], 3: [], 4: [] } })
    .onConflictDoNothing();
  const [created] = await db.select().from(appState).where(eq(appState.id, 1));
  return created;
}

/**
 * Draw permission is valid only while the admin session that enabled it is
 * still live. If that session has ended (logout or expiry) the permission is
 * switched off and the change is written to the audit log.
 */
export async function drawPermission() {
  const state = await getState();
  if (!state.drawEnabled || !state.drawSessionId) return { active: false, state };
  const [s] = await db
    .select()
    .from(sessions)
    .where(
      and(
        eq(sessions.id, state.drawSessionId),
        eq(sessions.kind, "admin"),
        isNull(sessions.revokedAt),
        gt(sessions.expiresAt, new Date()),
      ),
    );
  if (s) return { active: true, state, expiresAt: s.expiresAt };
  const [updated] = await db
    .update(appState)
    .set({ drawEnabled: false, drawSessionId: null, updatedAt: new Date() })
    .where(and(eq(appState.id, 1), eq(appState.drawSessionId, state.drawSessionId)))
    .returning();
  if (updated) {
    await audit({ type: "system" }, "draw_permission_expired", "draw_permission", "1", {
      reason: "Enabling administrator session ended or expired",
    });
  }
  return { active: false, state: updated || state };
}

// ---------- Audit ----------

export type Actor = { type: "admin" | "player" | "system"; id?: number; name?: string };

export const adminActor = (ctx: AdminCtx): Actor => ({ type: "admin", id: ctx.admin.id, name: ctx.admin.username });
export const playerActor = (ctx: PlayerCtx): Actor => ({ type: "player", id: ctx.player.id, name: ctx.player.name });

export async function audit(
  actor: Actor,
  action: string,
  targetType: string | null,
  targetId: string | number | null,
  details: Record<string, unknown> = {},
  tx: any = db,
) {
  await tx.insert(auditLog).values({
    actorType: actor.type,
    actorId: actor.id ?? null,
    actorName: actor.name ?? null,
    action,
    targetType,
    targetId: targetId === null ? null : String(targetId),
    details,
  });
}

// ---------- Uploaded files ----------

export function sniffFileType(bytes: Uint8Array): { mime: string; ext: string } | null {
  const b = bytes;
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { mime: "image/jpeg", ext: "jpg" };
  if (b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 && b[4] === 0x0d && b[5] === 0x0a && b[6] === 0x1a && b[7] === 0x0a)
    return { mime: "image/png", ext: "png" };
  if (b.length >= 12 && String.fromCharCode(...b.slice(0, 4)) === "RIFF" && String.fromCharCode(...b.slice(8, 12)) === "WEBP")
    return { mime: "image/webp", ext: "webp" };
  if (b.length >= 5 && String.fromCharCode(...b.slice(0, 5)) === "%PDF-") return { mime: "application/pdf", ext: "pdf" };
  return null;
}

export async function readProofFile(form: FormData, required: boolean) {
  const file = form.get("file");
  if (!file || typeof file === "string" || file.size === 0) {
    if (required) fail(400, "Please choose a payment receipt or screenshot to upload");
    return null;
  }
  if (file.size > MAX_PROOF_BYTES) fail(413, "File is too large. The maximum size is 4 MB.");
  const bytes = new Uint8Array(await file.arrayBuffer());
  const type = sniffFileType(bytes);
  if (!type) fail(415, "Unsupported file. Upload a JPG, PNG, WebP image or a PDF receipt.");
  const fileName = (file.name || `receipt.${type!.ext}`).replace(/[^\w.\- ]+/g, "_").slice(0, 120);
  return { bytes, mime: type!.mime, ext: type!.ext, fileName, size: bytes.length };
}
