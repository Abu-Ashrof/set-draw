import { getStore } from "@netlify/blobs";
import { randomUUID } from "node:crypto";
import { and, asc, desc, eq, inArray, isNull, ne, sql } from "drizzle-orm";
import { db } from "../db/index.js";
import {
  appState,
  contributionMembers,
  contributionPools,
  drawEvents,
  notifications,
  players,
  proofFiles,
  ticketLedger,
  ticketOrders,
} from "../db/schema.js";
import {
  ADMIN_COOKIE,
  MAX_OPEN_ORDERS,
  MAX_TICKETS_PER_ORDER,
  PLAYER_COOKIE,
  PLAYER_SESSION_MS,
  STATUS_POLICY,
  TICKET_PRICE,
  audit,
  can,
  clearCookie,
  createSession,
  drawPermission,
  fail,
  getAdmin,
  getPlayer,
  getState,
  intIn,
  json,
  lockedMessage,
  nextFailure,
  playerActor,
  adminActor,
  randomRef,
  readJson,
  readProofFile,
  requireCan,
  requirePlayer,
  revokeSession,
  sessionCookie,
  str,
  validPin,
  verifySecret,
  hashSecret,
  type Actor,
  type AdminCtx,
  type PlayerCtx,
} from "./lib.js";

export const proofStore = () => getStore({ name: "payment-proofs", consistency: "strong" });

export function accountOf(state: { accountNumber: string; bankName: string; accountName: string }) {
  return { accountNumber: state.accountNumber, bankName: state.bankName, accountName: state.accountName };
}

const proofSummary = (p: typeof proofFiles.$inferSelect | undefined | null) =>
  p ? { id: p.id, fileName: p.fileName, mimeType: p.mimeType, sizeBytes: p.sizeBytes, uploadedAt: p.uploadedAt, url: `/api/proofs/${p.id}` } : null;

export async function proofsByIds(ids: (number | null)[]) {
  const clean = ids.filter((x): x is number => typeof x === "number");
  if (!clean.length) return new Map<number, typeof proofFiles.$inferSelect>();
  const rows = await db.select().from(proofFiles).where(inArray(proofFiles.id, clean));
  return new Map(rows.map((r) => [r.id, r]));
}

export async function withProofs<T extends { proofId: number | null }>(rows: T[]) {
  const map = await proofsByIds(rows.map((r) => r.proofId));
  return rows.map((r) => ({ ...r, proof: proofSummary(r.proofId ? map.get(r.proofId) : null) }));
}

/** Saves the file to Blobs and records it. Returns the proof_files row. */
export async function storeProof(
  playerId: number,
  ownerType: "ticket_order" | "contribution",
  ownerId: number,
  file: { bytes: Uint8Array; mime: string; ext: string; fileName: string; size: number },
) {
  const key = `${ownerType}/${ownerId}/${randomUUID()}.${file.ext}`;
  try {
    await proofStore().set(key, file.bytes.buffer.slice(file.bytes.byteOffset, file.bytes.byteOffset + file.bytes.byteLength) as ArrayBuffer);
  } catch (e) {
    console.error("Blob upload failed", e);
    fail(502, "The file could not be stored. Please try again.");
  }
  const [row] = await db
    .insert(proofFiles)
    .values({ playerId, ownerType, ownerId, blobKey: key, mimeType: file.mime, fileName: file.fileName, sizeBytes: file.size })
    .returning();
  return row;
}

export async function notify(playerId: number, message: string, tx: any = db) {
  await tx.insert(notifications).values({ playerId, message });
}

// ---------- Public state ----------

export async function getPublicState(req: Request) {
  const [adminCtx, playerCtx, perm] = await Promise.all([getAdmin(req), getPlayer(req), drawPermission()]);
  const state = perm.state;
  const all = await db.select().from(players).orderBy(asc(players.createdAt), asc(players.id));
  const setOf = new Map<number, string>();
  for (const [k, ids] of Object.entries(state.assignments || {})) for (const id of ids) setOf.set(id, k);
  const list = all.map((p) => ({
    id: p.id,
    name: p.name,
    role: p.role,
    status: p.status,
    present: p.present,
    // "blocked" mirrors the original app: no tickets or not allowed to play.
    blocked: p.ticketBalance <= 0 || !can(p, "presence"),
    set: setOf.get(p.id) || null,
    ...(adminCtx ? { tickets: p.ticketBalance } : {}),
  }));
  const me = playerCtx
    ? {
        id: playerCtx.player.id,
        name: playerCtx.player.name,
        status: playerCtx.player.status,
        tickets: playerCtx.player.ticketBalance,
      }
    : null;
  return json({
    settings: { numSets: state.numSets, playersPerSet: state.playersPerSet, ticketPrice: TICKET_PRICE },
    account: accountOf(state),
    players: list,
    assignments: state.assignments,
    drawConfirmed: state.drawConfirmed,
    draw: { permissionActive: perm.active, enabledAt: perm.active ? state.drawEnabledAt : null },
    me,
    admin: adminCtx ? { username: adminCtx.admin.username, expiresAt: adminCtx.session.expiresAt } : null,
    statusPolicy: STATUS_POLICY,
  });
}

// ---------- Player auth ----------

export async function playerLogin(req: Request) {
  const body = await readJson(req);
  const playerId = intIn(body.playerId, 1, 2 ** 31 - 1, "Player");
  const pin = typeof body.pin === "string" ? body.pin.trim() : "";
  const [p] = await db.select().from(players).where(eq(players.id, playerId));
  if (!p) fail(404, "Player not found");
  const locked = lockedMessage(p!.lockedUntil);
  if (locked) fail(429, locked);
  if (!pin || !(await verifySecret(pin, p!.pinHash))) {
    await db.update(players).set(nextFailure(p!.failedLogins)).where(eq(players.id, p!.id));
    fail(401, "Incorrect PIN");
  }
  await db.update(players).set({ failedLogins: 0, lockedUntil: null }).where(eq(players.id, p!.id));
  // Replace any existing player session in this browser.
  await revokeSession(req, PLAYER_COOKIE, "player");
  const { token } = await createSession("player", p!.id, PLAYER_SESSION_MS);
  await audit({ type: "player", id: p!.id, name: p!.name }, "player_login", "player", p!.id);
  return json({ ok: true }, 200, { "set-cookie": sessionCookie(req, PLAYER_COOKIE, token, PLAYER_SESSION_MS) });
}

export async function playerLogout(req: Request) {
  await revokeSession(req, PLAYER_COOKIE, "player");
  return json({ ok: true }, 200, { "set-cookie": clearCookie(req, PLAYER_COOKIE) });
}

export async function changePin(req: Request) {
  const ctx = await requirePlayer(req);
  const body = await readJson(req);
  if (!(await verifySecret(String(body.currentPin || ""), ctx.player.pinHash))) fail(401, "Current PIN is incorrect");
  const pin = validPin(body.newPin);
  await db.update(players).set({ pinHash: await hashSecret(pin), updatedAt: new Date() }).where(eq(players.id, ctx.player.id));
  await audit(playerActor(ctx), "player_pin_changed", "player", ctx.player.id);
  return json({ ok: true });
}

// ---------- Player dashboard ----------

export async function playerRecords(playerId: number) {
  const [orders, ledger, members, notes] = await Promise.all([
    db.select().from(ticketOrders).where(eq(ticketOrders.playerId, playerId)).orderBy(desc(ticketOrders.createdAt)),
    db.select().from(ticketLedger).where(eq(ticketLedger.playerId, playerId)).orderBy(desc(ticketLedger.createdAt), desc(ticketLedger.id)),
    db
      .select({ member: contributionMembers, pool: contributionPools })
      .from(contributionMembers)
      .innerJoin(contributionPools, eq(contributionMembers.poolId, contributionPools.id))
      .where(and(eq(contributionMembers.playerId, playerId), ne(contributionPools.status, "draft")))
      .orderBy(desc(contributionPools.createdAt)),
    db.select().from(notifications).where(eq(notifications.playerId, playerId)).orderBy(desc(notifications.createdAt)).limit(30),
  ]);
  const ordersWithProofs = await withProofs(orders);
  const memberProofs = await proofsByIds(members.map((m) => m.member.proofId));
  const contributions = members.map(({ member, pool }) => ({
    ...member,
    proof: proofSummary(member.proofId ? memberProofs.get(member.proofId) : null),
    pool: {
      id: pool.id,
      title: pool.title,
      description: pool.description,
      type: pool.type,
      amountPerPlayer: pool.amountPerPlayer,
      otherRequirement: pool.otherRequirement,
      startDate: pool.startDate,
      deadline: pool.deadline,
      accountNumber: pool.accountNumber,
      bankName: pool.bankName,
      accountName: pool.accountName,
      instructions: pool.instructions,
      status: pool.status,
    },
  }));
  const approved = orders.filter((o) => o.status === "approved");
  const stats = {
    totalTicketsPurchased: approved.reduce((s, o) => s + o.quantity, 0),
    totalAmountPaid: approved.reduce((s, o) => s + o.amount, 0),
    pending: orders.filter((o) => ["awaiting_payment", "proof_submitted", "under_review"].includes(o.status)).length,
    approved: approved.length,
    rejected: orders.filter((o) => o.status === "rejected").length,
  };
  return { orders: ordersWithProofs, ledger, contributions, notifications: notes, stats };
}

export async function getMe(req: Request) {
  const ctx = await requirePlayer(req);
  const p = ctx.player;
  const state = await getState();
  const records = await playerRecords(p.id);
  return json({
    player: { id: p.id, name: p.name, role: p.role, status: p.status, statusReason: p.statusReason, tickets: p.ticketBalance, present: p.present },
    permissions: STATUS_POLICY[(p.status as keyof typeof STATUS_POLICY)] || STATUS_POLICY.disabled,
    account: accountOf(state),
    ticketPrice: TICKET_PRICE,
    ...records,
  });
}

export async function markNotificationsRead(req: Request) {
  const ctx = await requirePlayer(req);
  await db
    .update(notifications)
    .set({ readAt: new Date() })
    .where(and(eq(notifications.playerId, ctx.player.id), isNull(notifications.readAt)));
  return json({ ok: true });
}

export async function setOwnPresence(req: Request) {
  const ctx = await requirePlayer(req);
  const body = await readJson(req);
  const present = !!body.present;
  if (present) {
    requireCan(ctx.player, "presence");
    if (ctx.player.ticketBalance <= 0) fail(403, "You need at least 1 ticket to be marked present");
  }
  await db.update(players).set({ present, updatedAt: new Date() }).where(eq(players.id, ctx.player.id));
  return json({ ok: true });
}

// ---------- Ticket orders ----------

export async function createOrder(req: Request) {
  const ctx = await requirePlayer(req);
  requireCan(ctx.player, "buy");
  const body = await readJson(req);
  const quantity = intIn(body.quantity, 1, MAX_TICKETS_PER_ORDER, "Number of tickets");
  const [{ open }] = await db
    .select({ open: sql<number>`count(*)::int` })
    .from(ticketOrders)
    .where(and(eq(ticketOrders.playerId, ctx.player.id), eq(ticketOrders.status, "awaiting_payment")));
  if (open >= MAX_OPEN_ORDERS) fail(409, `You already have ${open} orders awaiting payment. Complete or cancel one first.`);
  const state = await getState();
  for (let attempt = 0; attempt < 5; attempt++) {
    const reference = randomRef("TKT");
    const [order] = await db
      .insert(ticketOrders)
      .values({
        reference,
        playerId: ctx.player.id,
        quantity,
        unitPrice: TICKET_PRICE,
        amount: quantity * TICKET_PRICE, // always computed on the server
        ...accountOf(state),
      })
      .onConflictDoNothing()
      .returning();
    if (order) {
      await audit(playerActor(ctx), "ticket_order_created", "ticket_order", order.id, { reference, quantity, amount: order.amount });
      return json({ order: { ...order, proof: null } }, 201);
    }
  }
  return fail(500, "Could not create an order reference. Please try again.");
}

async function ownOrder(ctx: PlayerCtx, id: number) {
  const [order] = await db.select().from(ticketOrders).where(and(eq(ticketOrders.id, id), eq(ticketOrders.playerId, ctx.player.id)));
  // Same response whether the order belongs to someone else or doesn't exist.
  if (!order) fail(404, "Order not found");
  return order!;
}

export async function cancelOrder(req: Request, id: number) {
  const ctx = await requirePlayer(req);
  await ownOrder(ctx, id);
  const [row] = await db
    .update(ticketOrders)
    .set({ status: "cancelled" })
    .where(and(eq(ticketOrders.id, id), eq(ticketOrders.status, "awaiting_payment")))
    .returning();
  if (!row) fail(409, "Only orders awaiting payment can be cancelled");
  await audit(playerActor(ctx), "ticket_order_cancelled", "ticket_order", id, { reference: row!.reference });
  return json({ ok: true });
}

export async function uploadOrderProof(req: Request, id: number) {
  const ctx = await requirePlayer(req);
  requireCan(ctx.player, "uploadOrderProof");
  const order = await ownOrder(ctx, id);
  if (!["awaiting_payment", "rejected"].includes(order.status)) {
    fail(409, order.status === "approved" ? "This order is already approved." : "Proof for this order has already been submitted and is awaiting review.");
  }
  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return fail(400, "Upload could not be read. Please choose the file again.");
  }
  const paymentDate = str(form.get("paymentDate"), "Payment date", { max: 10 });
  if (paymentDate && !/^\d{4}-\d{2}-\d{2}$/.test(paymentDate)) fail(400, "Payment date is not valid");
  const file = await readProofFile(form, true);
  const proof = await storeProof(ctx.player.id, "ticket_order", order.id, file!);
  // Conditional update guards against two simultaneous submissions.
  const [updated] = await db
    .update(ticketOrders)
    .set({
      status: "proof_submitted",
      proofId: proof.id,
      paymentDate: paymentDate || null,
      submittedAt: new Date(),
      rejectionReason: order.status === "rejected" ? order.rejectionReason : null,
    })
    .where(and(eq(ticketOrders.id, order.id), inArray(ticketOrders.status, ["awaiting_payment", "rejected"])))
    .returning();
  if (!updated) fail(409, "This order was already submitted.");
  await audit(playerActor(ctx), order.status === "rejected" ? "ticket_proof_resubmitted" : "ticket_proof_submitted", "ticket_order", order.id, {
    reference: order.reference,
    proofId: proof.id,
    fileName: proof.fileName,
  });
  return json({ order: { ...updated, proof: proofSummary(proof) } });
}

// ---------- Contributions (player side) ----------

export async function submitContribution(req: Request, memberId: number) {
  const ctx = await requirePlayer(req);
  requireCan(ctx.player, "contribute");
  const [row] = await db
    .select({ member: contributionMembers, pool: contributionPools })
    .from(contributionMembers)
    .innerJoin(contributionPools, eq(contributionMembers.poolId, contributionPools.id))
    .where(and(eq(contributionMembers.id, memberId), eq(contributionMembers.playerId, ctx.player.id)));
  if (!row) fail(404, "Contribution not found");
  const { member, pool } = row!;
  if (pool.status !== "open") fail(409, "This contribution is not open for submissions");
  if (!["not_paid", "rejected"].includes(member.status)) fail(409, "You have already submitted this contribution");
  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return fail(400, "Submission could not be read. Please try again.");
  }
  const isMoney = pool.type === "money";
  const amount = isMoney ? intIn(form.get("amount"), 1, 100_000_000, "Amount paid") : null;
  const paidDate = str(form.get("paidDate"), "Date paid", { max: 10 });
  if (paidDate && !/^\d{4}-\d{2}-\d{2}$/.test(paidDate)) fail(400, "Date paid is not valid");
  const note = str(form.get("note"), "Note", { max: 1000 });
  if (!isMoney && !note) fail(400, "Please describe what you contributed");
  const file = await readProofFile(form, isMoney);
  const proof = file ? await storeProof(ctx.player.id, "contribution", member.id, file) : null;
  const [updated] = await db
    .update(contributionMembers)
    .set({
      status: "pending_verification",
      amountContributed: amount,
      paidDate: paidDate || null,
      note: note || null,
      proofId: proof ? proof.id : member.proofId,
      submittedAt: new Date(),
    })
    .where(and(eq(contributionMembers.id, member.id), inArray(contributionMembers.status, ["not_paid", "rejected"])))
    .returning();
  if (!updated) fail(409, "This contribution was already submitted");
  await audit(playerActor(ctx), "contribution_submitted", "contribution_member", member.id, {
    poolId: pool.id,
    pool: pool.title,
    amount,
    proofId: proof?.id ?? null,
  });
  return json({ ok: true });
}

// ---------- Proof files ----------

export async function getProof(req: Request, id: number) {
  const [file] = await db.select().from(proofFiles).where(eq(proofFiles.id, id));
  const adminCtx = await getAdmin(req);
  let allowed = !!adminCtx;
  if (!allowed && file) {
    const p = await getPlayer(req);
    allowed = !!p && p.player.id === file.playerId;
  }
  if (!file || !allowed) return json({ error: "Not found" }, 404);
  const data = await proofStore().get(file.blobKey, { type: "arrayBuffer" });
  if (!data) return json({ error: "File is missing from storage" }, 404);
  return new Response(data, {
    headers: {
      "content-type": file.mimeType,
      "content-disposition": `inline; filename="${file.fileName.replace(/"/g, "")}"`,
      "cache-control": "private, no-store",
      "x-content-type-options": "nosniff",
      "content-security-policy": "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox",
    },
  });
}

// ---------- Draw ----------

function shuffle<T>(arr: T[]) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Who is asking to operate the draw, and are they allowed to right now? */
async function drawActor(req: Request): Promise<{ actor: Actor; admin?: AdminCtx }> {
  const adminCtx = await getAdmin(req, true);
  if (adminCtx) return { actor: adminActor(adminCtx), admin: adminCtx };
  const playerCtx = await getPlayer(req);
  if (!playerCtx) fail(401, "Sign in as an administrator, or as a player while draws are enabled");
  const perm = await drawPermission();
  const actor = playerActor(playerCtx!);
  const deny = async (msg: string) => {
    await db.insert(drawEvents).values({ type: "denied", actorType: "player", actorId: actor.id, actorName: actor.name, details: { reason: msg } });
    fail(403, msg);
  };
  if (!perm.active) await deny("Draws are locked. An administrator must be signed in and enable draws.");
  if (!can(playerCtx!.player, "draw")) await deny(`Your account is ${playerCtx!.player.status}, so you cannot make draws.`);
  if (playerCtx!.player.ticketBalance <= 0) await deny("You need at least 1 ticket to make a draw.");
  return { actor };
}

export async function runDraw(req: Request) {
  const { actor } = await drawActor(req);
  const result = await db.transaction(async (tx) => {
    const [state] = await tx.select().from(appState).where(eq(appState.id, 1)).for("update");
    if (state.drawConfirmed) fail(409, "This draw is already confirmed. Start a new matchday to draw again.");
    const assignments: Record<string, number[]> = {};
    for (let s = 1; s <= state.numSets; s++) assignments[s] = [...(state.assignments?.[s] || [])];
    const assigned = new Set(Object.values(assignments).flat());
    const all = await tx.select().from(players);
    const byId = new Map(all.map((p) => [p.id, p]));
    const eligible = all.filter((p) => p.present && p.status === "active" && p.ticketBalance > 0 && !assigned.has(p.id));
    if (!eligible.length) fail(409, "No present, eligible players to add to a set");
    const fPool = shuffle(eligible.filter((p) => p.role !== "defend").map((p) => p.id));
    const dPool = shuffle(eligible.filter((p) => p.role === "defend").map((p) => p.id));
    // Same sequential, role-balanced fill as the original app.
    let placed = 0;
    for (let s = 1; s <= state.numSets; s++) {
      const arr = assignments[s];
      while (arr.length < state.playersPerSet && (fPool.length || dPool.length)) {
        const f = arr.filter((id) => byId.get(id)?.role !== "defend").length;
        const d = arr.length - f;
        if (f <= d && fPool.length) arr.push(fPool.shift()!);
        else if (dPool.length) arr.push(dPool.shift()!);
        else if (fPool.length) arr.push(fPool.shift()!);
        else break;
        placed++;
      }
      if (!fPool.length && !dPool.length) break;
    }
    const overflow = fPool.length + dPool.length;
    await tx.update(appState).set({ assignments, updatedAt: new Date() }).where(eq(appState.id, 1));
    await tx.insert(drawEvents).values({ type: "run", actorType: actor.type, actorId: actor.id, actorName: actor.name, details: { placed, overflow, assignments } });
    return { placed, overflow };
  });
  return json(result);
}

export async function resetDraw(req: Request) {
  const { actor } = await drawActor(req);
  await db.transaction(async (tx) => {
    const [state] = await tx.select().from(appState).where(eq(appState.id, 1)).for("update");
    if (state.drawConfirmed) fail(409, "A confirmed draw cannot be reset");
    const fresh: Record<string, number[]> = {};
    for (let s = 1; s <= state.numSets; s++) fresh[s] = [];
    await tx.update(appState).set({ assignments: fresh, updatedAt: new Date() }).where(eq(appState.id, 1));
    await tx.insert(drawEvents).values({ type: "reset", actorType: actor.type, actorId: actor.id, actorName: actor.name, details: { previous: state.assignments } });
  });
  return json({ ok: true });
}

export async function confirmDraw(req: Request) {
  const { actor } = await drawActor(req);
  const result = await db.transaction(async (tx) => {
    const [state] = await tx.select().from(appState).where(eq(appState.id, 1)).for("update");
    if (state.drawConfirmed) fail(409, "This draw is already confirmed");
    const ids = Object.values(state.assignments || {}).flat();
    if (!ids.length) fail(409, "Nothing to confirm — run the draw first");
    const reference = randomRef("DRAW");
    let charged = 0;
    let newlyBlocked = 0;
    const rows = await tx.select().from(players).where(inArray(players.id, ids)).for("update");
    for (const p of rows) {
      if (p.ticketBalance <= 0) continue;
      const after = p.ticketBalance - 1;
      await tx
        .update(players)
        .set({ ticketBalance: after, present: after > 0 ? p.present : false, updatedAt: new Date() })
        .where(eq(players.id, p.id));
      await tx.insert(ticketLedger).values({
        playerId: p.id,
        type: "draw",
        delta: -1,
        balanceBefore: p.ticketBalance,
        balanceAfter: after,
        reference,
        adminId: actor.type === "admin" ? actor.id : null,
        adminName: actor.type === "admin" ? actor.name : null,
        reason: `Matchday draw confirmed by ${actor.name} (${actor.type})`,
      });
      charged++;
      if (after <= 0) newlyBlocked++;
    }
    await tx.update(appState).set({ drawConfirmed: true, updatedAt: new Date() }).where(eq(appState.id, 1));
    await tx.insert(drawEvents).values({
      type: "confirm",
      actorType: actor.type,
      actorId: actor.id,
      actorName: actor.name,
      details: { reference, drawn: ids.length, charged, assignments: state.assignments },
    });
    return { drawn: ids.length, charged, newlyBlocked, reference };
  });
  return json(result);
}

export { ADMIN_COOKIE };
