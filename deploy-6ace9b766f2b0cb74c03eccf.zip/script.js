const STORAGE_KEY = 'matchday-data-v1';
const PRICE_PER_TICKET = 100;
const PAYMENT_ACCOUNT = { number: '8022447576', provider: 'Smart xash', name: 'Abdulhameed Abdulkareem' };
const ADMIN_PASSCODE = 'admin123'; // Client-side-only gate — visible in page source. Not real security.

let state = {
  players: [],
  assignments: {1:[],2:[],3:[],4:[]},
  settings: { numSets: 4, playersPerSet: 6 },
  drawConfirmed: false,
  payments: []
};

let searchTerm = '';
let showPresentNames = false;
let isAdmin = false;
let purchaseState = null;

// ============================================================
// SHARED CLOUD SYNC — fill these in with your own Firebase project
// (console.firebase.google.com → create project → Realtime Database →
// Project settings → your app's config). Without this filled in,
// the app still works but only on this one device/browser.
// ============================================================
const firebaseConfig = {
  apiKey: "PASTE_YOUR_API_KEY_HERE",
  authDomain: "PASTE_YOUR_PROJECT.firebaseapp.com",
  databaseURL: "https://PASTE_YOUR_PROJECT-default-rtdb.firebaseio.com",
  projectId: "PASTE_YOUR_PROJECT_ID"
};

let firebaseReady = false;
let stateRef = null;
try{
  if(firebaseConfig.apiKey && firebaseConfig.apiKey.indexOf('PASTE_YOUR') === -1){
    firebase.initializeApp(firebaseConfig);
    stateRef = firebase.database().ref('matchday-data-v1');
    firebaseReady = true;
  }
}catch(e){
  console.error('Firebase init failed', e);
}

function uid(){ return 'id' + Math.random().toString(36).slice(2,10); }

function showToast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(()=> t.classList.remove('show'), 2600);
}

// ---- Persistence: localStorage as an instant local cache, Firebase as
// the shared source of truth that pushes updates to every open copy of
// this page automatically. ----
function saveState(){
  try{
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }catch(e){
    showToast('Local save error: ' + (e && e.message ? e.message : String(e)));
  }
  if(firebaseReady && stateRef){
    stateRef.set(state).catch(e => {
      showToast('Cloud sync error: ' + (e && e.message ? e.message : String(e)));
    });
  }
}

function applyLoadedState(parsed){
  state = {
    players: parsed.players || [],
    assignments: parsed.assignments || {1:[],2:[],3:[],4:[]},
    settings: parsed.settings || { numSets: 4, playersPerSet: 6 },
    drawConfirmed: !!parsed.drawConfirmed,
    payments: parsed.payments || []
  };
  document.getElementById('num-sets-input').value = state.settings.numSets;
  document.getElementById('per-set-input').value = state.settings.playersPerSet;
}

function loadState(){
  // 1) Render instantly from whatever is cached locally, so the app
  // isn't blank while we wait for the network.
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(raw){ applyLoadedState(JSON.parse(raw)); }
    else {
      document.getElementById('num-sets-input').value = state.settings.numSets;
      document.getElementById('per-set-input').value = state.settings.playersPerSet;
    }
  }catch(e){
    document.getElementById('num-sets-input').value = state.settings.numSets;
    document.getElementById('per-set-input').value = state.settings.playersPerSet;
  }
  document.getElementById('loading').style.display = 'none';
  document.getElementById('app').style.display = 'block';
  render();

  // 2) Subscribe to the shared cloud copy. This fires immediately with
  // whatever is currently saved, and again every time anyone — on any
  // device — saves a change, which is what makes updates appear for
  // everyone automatically without exporting/importing codes.
  if(firebaseReady && stateRef){
    stateRef.on('value', (snapshot) => {
      const data = snapshot.val();
      if(data){
        applyLoadedState(data);
        try{ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }catch(e){}
        render();
      }
    }, (error) => {
      showToast('Cloud sync unavailable: ' + error.message);
    });
  } else {
    showToast('Cloud sync isn\'t set up yet — changes will only save on this device. See the setup note at the top of the code.');
  }
}

function playerSetNumber(playerId){
  for(const setNum of Object.keys(state.assignments)){
    if(state.assignments[setNum].includes(playerId)) return setNum;
  }
  return null;
}

function escapeHtml(str){
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}

function render(){
  document.getElementById('player-count').textContent = state.players.length;

  // admin toggle UI
  document.getElementById('admin-login-row').style.display = isAdmin ? 'none' : 'flex';
  document.getElementById('admin-status-row').style.display = isAdmin ? 'flex' : 'none';
  document.getElementById('admin-panel').style.display = isAdmin ? 'block' : 'none';

  // player list
  const list = document.getElementById('player-list');
  const term = searchTerm.trim().toLowerCase();
  const visiblePlayers = term ? state.players.filter(p => p.name.toLowerCase().includes(term)) : state.players;
  if(state.players.length === 0){
    list.innerHTML = '<div class="empty">No players yet — add the first name above.</div>';
  } else if(visiblePlayers.length === 0){
    list.innerHTML = '<div class="empty">No players match that search.</div>';
  } else {
    list.innerHTML = '';
    visiblePlayers.forEach(p => {
      const row = document.createElement('div');
      row.className = 'player-row';
      const setNum = playerSetNumber(p.id);
      const roleClass = p.role === 'defend' ? 'role-defend' : 'role-forward';
      const roleLabel = p.role === 'defend' ? 'Defend' : 'Forward';
      const ticketHtml = isAdmin
        ? `<div class="ticket-field"><label for="ticket-${p.id}">Tickets</label><input id="ticket-${p.id}" type="number" min="0" max="99" data-id="${p.id}" class="ticket-input" value="${p.tickets}" /></div>`
        : `<span class="ticket-display">Tickets: ${p.tickets}</span>`;
      row.innerHTML = `
        <div class="name">
          ${escapeHtml(p.name)}
          <span class="role-badge ${roleClass}">${roleLabel}</span>
          ${setNum ? `<span class="badge-set">Set ${setNum}</span>` : ''}
          ${p.blocked ? '<span class="blocked-tag">Blocked</span>' : ''}
        </div>
        <div class="row-actions">
          ${ticketHtml}
          <button class="btn-ghost btn-sm view-history-btn" data-id="${p.id}">View</button>
          <button class="btn-amber btn-sm purchase-btn" data-id="${p.id}">Purchase</button>
          <label class="presence-toggle ${p.blocked ? 'is-disabled' : ''}">
            <input type="checkbox" data-id="${p.id}" class="present-check" ${p.present ? 'checked' : ''} ${p.blocked ? 'disabled' : ''}/>
            Present
          </label>
          <button class="remove-x" data-id="${p.id}" title="Delete member">&times;</button>
        </div>
      `;
      list.appendChild(row);
    });
  }

  // sets grid
  const grid = document.getElementById('sets-grid');
  grid.innerHTML = '';
  const numSets = state.settings.numSets;
  const perSet = state.settings.playersPerSet;
  for(let i=1;i<=numSets;i++){
    const ids = state.assignments[i] || [];
    const card = document.createElement('div');
    card.className = 'set-card';
    const rosterPlayers = ids.map(id => state.players.find(pl => pl.id === id)).filter(Boolean);
    const fCount = rosterPlayers.filter(p => p.role !== 'defend').length;
    const dCount = rosterPlayers.filter(p => p.role === 'defend').length;
    card.innerHTML = `
      <div class="set-num">
        <span>Set <span class="n">${i}</span></span>
        <span class="cap">${rosterPlayers.length}/${perSet} player${perSet===1?'':'s'}<br>${fCount}F &middot; ${dCount}D</span>
      </div>
      <ul class="set-players">
        ${rosterPlayers.length ? rosterPlayers.map((p,idx)=>`<li style="animation-delay:${idx*0.05}s"><span>${escapeHtml(p.name)}</span><span class="role-badge ${p.role==='defend'?'role-defend':'role-forward'}">${p.role==='defend'?'D':'F'}</span></li>`).join('') : '<li class="set-empty" style="animation:none;opacity:1;transform:none;">Not drawn yet</li>'}
      </ul>
    `;
    grid.appendChild(card);
  }

  const banner = document.getElementById('confirmed-banner');
  banner.innerHTML = state.drawConfirmed
    ? '<div class="confirmed-banner">This draw has been confirmed and sealed. Start a new matchday to draw again.</div>'
    : '';
  document.getElementById('draw-btn').disabled = state.drawConfirmed;
  document.getElementById('reset-draw-btn').disabled = state.drawConfirmed;

  const presentPlayers = state.players.filter(p => p.present);
  const presentF = presentPlayers.filter(p => p.role !== 'defend').length;
  const presentD = presentPlayers.filter(p => p.role === 'defend').length;
  document.getElementById('present-summary-text').textContent =
    `${presentPlayers.length} present \u00B7 ${presentF}F \u00B7 ${presentD}D`;
  document.getElementById('toggle-present-btn').textContent = showPresentNames ? 'Hide names' : 'Show names';
  const namesList = document.getElementById('present-names-list');
  if(showPresentNames){
    namesList.style.display = 'flex';
    namesList.innerHTML = presentPlayers.length
      ? presentPlayers.map(p => `<div class="present-name-item"><span>${escapeHtml(p.name)}</span><span class="role-badge ${p.role==='defend'?'role-defend':'role-forward'}">${p.role==='defend'?'D':'F'}</span></div>`).join('')
      : '<div class="empty">No players marked present yet.</div>';
  } else {
    namesList.style.display = 'none';
  }

  // admin payments list
  if(isAdmin){
    const adminList = document.getElementById('admin-payments-list');
    const sorted = [...state.payments].sort((a,b) => b.createdAt - a.createdAt);
    adminList.innerHTML = sorted.length ? sorted.map(pay => {
      const player = state.players.find(p => p.id === pay.playerId);
      const playerName = player ? player.name : 'Unknown player';
      return `
        <div class="history-item">
          <div>
            <strong>${escapeHtml(playerName)}</strong> &middot; ${pay.quantity} ticket(s) &middot; \u20A6${pay.amount}
            <br><span class="status-badge status-${pay.status}">${pay.status}</span>
            <span style="color:var(--muted);font-size:11px;margin-left:8px;">${new Date(pay.createdAt).toLocaleString()}</span>
          </div>
          ${pay.proofDataUrl ? `<img class="proof-thumb" src="${pay.proofDataUrl}" alt="payment proof" />` : '<span style="font-size:11px;color:var(--muted);">No proof attached</span>'}
          ${pay.status === 'pending' ? `
            <div style="display:flex;gap:6px;">
              <button class="btn-amber btn-sm approve-payment-btn" data-id="${pay.id}">Approve</button>
              <button class="btn-ghost btn-sm reject-payment-btn" data-id="${pay.id}">Reject</button>
            </div>` : ''}
        </div>
      `;
    }).join('') : '<div class="empty">No payment requests yet.</div>';

    document.querySelectorAll('.approve-payment-btn').forEach(btn => {
      btn.onclick = () => approvePayment(btn.dataset.id);
    });
    document.querySelectorAll('.reject-payment-btn').forEach(btn => {
      btn.onclick = () => rejectPayment(btn.dataset.id);
    });
  }

  // wire up player-row events
  document.querySelectorAll('.ticket-input').forEach(inp => {
    inp.onchange = (e) => {
      const id = e.target.dataset.id;
      const p = state.players.find(pl => pl.id === id);
      if(!p) return;
      let val = parseInt(e.target.value, 10);
      if(isNaN(val) || val < 0) val = 0;
      p.tickets = val;
      const wasBlocked = p.blocked;
      p.blocked = p.tickets <= 0;
      if(p.blocked){ p.present = false; }
      saveState();
      render();
      if(p.blocked && !wasBlocked){ showToast(`${p.name} is out of tickets and has been blocked`); }
    };
  });
  document.querySelectorAll('.present-check').forEach(cb => {
    cb.onchange = (e) => {
      const id = e.target.dataset.id;
      const p = state.players.find(pl => pl.id === id);
      if(p && !p.blocked){ p.present = e.target.checked; saveState(); render(); }
    };
  });
  document.querySelectorAll('.remove-x').forEach(btn => {
    btn.onclick = (e) => {
      const id = e.target.dataset.id;
      state.players = state.players.filter(p => p.id !== id);
      for(const k of Object.keys(state.assignments)){
        state.assignments[k] = state.assignments[k].filter(pid => pid !== id);
      }
      saveState();
      render();
    };
  });
  document.querySelectorAll('.view-history-btn').forEach(btn => {
    btn.onclick = () => openHistoryModal(btn.dataset.id);
  });
  document.querySelectorAll('.purchase-btn').forEach(btn => {
    btn.onclick = () => openPurchaseModal(btn.dataset.id);
  });
}

document.getElementById('add-btn').onclick = () => {
  const input = document.getElementById('name-input');
  const roleInput = document.getElementById('role-input');
  const name = input.value.trim();
  if(!name){ return; }
  if(state.players.some(p => p.name.toLowerCase() === name.toLowerCase())){
    showToast('That name is already on the list');
    return;
  }
  state.players.push({
    id: uid(),
    name,
    role: roleInput.value === 'defend' ? 'defend' : 'forward',
    tickets: 0,
    present: false,
    blocked: true
  });
  input.value = '';
  saveState();
  render();
};

document.getElementById('name-input').addEventListener('keydown', (e) => {
  if(e.key === 'Enter'){ document.getElementById('add-btn').click(); }
});

document.getElementById('search-input').addEventListener('input', (e) => {
  searchTerm = e.target.value;
  render();
});

document.getElementById('toggle-present-btn').onclick = () => {
  showPresentNames = !showPresentNames;
  render();
};

function shuffle(arr){
  const a = [...arr];
  for(let i = a.length - 1; i > 0; i--){
    const j = Math.floor(Math.random() * (i+1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Fills Set 1 completely before moving on to Set 2, then Set 3, and so on.
// While filling whichever set is currently open, it still alternates
// between forwards and defends (picking whichever role is currently
// under-represented in that set) so each set ends up role-balanced too.
function distributeSequential(forwardIds, defendIds){
  const numSets = state.settings.numSets;
  const perSet = state.settings.playersPerSet;
  const fPool = [...forwardIds];
  const dPool = [...defendIds];
  let placed = 0;

  for(let s = 1; s <= numSets; s++){
    const arr = state.assignments[s] || (state.assignments[s] = []);
    while(arr.length < perSet && (fPool.length > 0 || dPool.length > 0)){
      const fCountInSet = arr.filter(id => {
        const pl = state.players.find(x => x.id === id);
        return pl && pl.role !== 'defend';
      }).length;
      const dCountInSet = arr.length - fCountInSet;

      let pickFrom = null;
      if(fCountInSet <= dCountInSet && fPool.length > 0){ pickFrom = 'f'; }
      else if(dPool.length > 0){ pickFrom = 'd'; }
      else if(fPool.length > 0){ pickFrom = 'f'; }

      if(pickFrom === 'f'){ arr.push(fPool.shift()); }
      else if(pickFrom === 'd'){ arr.push(dPool.shift()); }
      else { break; }
      placed++;
    }
    if(fPool.length === 0 && dPool.length === 0) break;
  }

  const overflow = fPool.length + dPool.length;
  return { placed, overflow };
}

document.getElementById('draw-btn').onclick = () => {
  if(state.drawConfirmed) return;
  const alreadyAssigned = new Set(Object.values(state.assignments).flat());
  const eligible = state.players.filter(p => p.present && !p.blocked && p.tickets > 0 && !alreadyAssigned.has(p.id));

  if(eligible.length === 0){
    showToast('No present, eligible players to add to a set');
    return;
  }

  const forwards = shuffle(eligible.filter(p => p.role !== 'defend').map(p => p.id));
  const defends = shuffle(eligible.filter(p => p.role === 'defend').map(p => p.id));

  const { placed, overflow } = distributeSequential(forwards, defends);

  saveState();
  render();
  if(overflow > 0){
    showToast(`Drew ${placed} player${placed===1?'':'s'} — sets are full, ${overflow} left undrawn`);
  } else {
    showToast(`Drew ${placed} player${placed===1?'':'s'} into sets, filled in order and balanced by role`);
  }
};

// ---- Custom in-app confirm dialog ----
let pendingConfirmAction = null;
function showConfirm(message, action){
  document.getElementById('confirm-message').textContent = message;
  pendingConfirmAction = action;
  document.getElementById('confirm-overlay').classList.add('show');
}
function hideConfirm(){
  document.getElementById('confirm-overlay').classList.remove('show');
  pendingConfirmAction = null;
}
document.getElementById('confirm-cancel-btn').onclick = hideConfirm;
document.getElementById('confirm-ok-btn').onclick = () => {
  const action = pendingConfirmAction;
  hideConfirm();
  if(action){ action(); }
};

document.getElementById('reset-draw-btn').onclick = () => {
  if(state.drawConfirmed) return;
  showConfirm('Reset the current draw? All set assignments will be cleared so you can redraw.', () => {
    const fresh = {};
    for(let s=1; s<=state.settings.numSets; s++){ fresh[s] = []; }
    state.assignments = fresh;
    saveState();
    render();
    showToast('Draw reset — ready to redraw');
  });
};

document.getElementById('confirm-draw-btn').onclick = () => {
  if(state.drawConfirmed){ showToast('This draw is already confirmed'); return; }
  const assignedIds = Object.values(state.assignments).flat();
  if(assignedIds.length === 0){
    showToast('Nothing to confirm — run the draw first');
    return;
  }
  showConfirm(`Confirm and seal today's draw? This will use up one ticket for each of the ${assignedIds.length} drawn player(s).`, () => {
    let newlyBlocked = 0;
    assignedIds.forEach(id => {
      const p = state.players.find(pl => pl.id === id);
      if(!p) return;
      p.tickets = Math.max(0, p.tickets - 1);
      if(p.tickets <= 0 && !p.blocked){ p.blocked = true; newlyBlocked++; }
      if(p.blocked){ p.present = false; }
    });
    state.drawConfirmed = true;
    saveState();
    render();
    showToast(`Draw confirmed for ${assignedIds.length} player${assignedIds.length===1?'':'s'}${newlyBlocked ? ` — ${newlyBlocked} now out of tickets` : ''}`);
  });
};

document.getElementById('new-matchday-btn').onclick = () => {
  showConfirm('Start a new matchday? This clears all sets and unmarks everyone as present.', () => {
    state.players.forEach(p => { if(!p.blocked){ p.present = false; } });
    const fresh = {};
    for(let s=1; s<=state.settings.numSets; s++){ fresh[s] = []; }
    state.assignments = fresh;
    state.drawConfirmed = false;
    saveState();
    render();
    showToast('New matchday started — mark who is present to begin the next draw');
  });
};

document.getElementById('save-btn').onclick = () => {
  saveState();
  showToast('Saved to this browser');
};

document.getElementById('apply-settings-btn').onclick = () => {
  const numSetsRaw = parseInt(document.getElementById('num-sets-input').value, 10);
  const perSetRaw = parseInt(document.getElementById('per-set-input').value, 10);

  const numSets = Math.min(Math.max(isNaN(numSetsRaw) ? state.settings.numSets : numSetsRaw, 1), 20);
  const perSet = Math.min(Math.max(isNaN(perSetRaw) ? state.settings.playersPerSet : perSetRaw, 1), 50);

  const newAssignments = {};
  for(let s=1; s<=numSets; s++){
    newAssignments[s] = state.assignments[s] || [];
    if(newAssignments[s].length > perSet){
      newAssignments[s] = newAssignments[s].slice(0, perSet);
    }
  }
  state.assignments = newAssignments;
  state.settings = { numSets, playersPerSet: perSet };

  document.getElementById('num-sets-input').value = numSets;
  document.getElementById('per-set-input').value = perSet;

  saveState();
  render();
  showToast('Settings updated');
};

// ---- Admin login ----
document.getElementById('admin-login-btn').onclick = () => {
  const val = document.getElementById('admin-pass-input').value;
  if(val === ADMIN_PASSCODE){
    isAdmin = true;
    document.getElementById('admin-pass-input').value = '';
    render();
    showToast('Admin mode unlocked');
  } else {
    showToast('Incorrect passcode');
  }
};
document.getElementById('admin-pass-input').addEventListener('keydown', (e) => {
  if(e.key === 'Enter'){ document.getElementById('admin-login-btn').click(); }
});
document.getElementById('admin-logout-btn').onclick = () => {
  isAdmin = false;
  render();
  showToast('Admin mode off');
};

function approvePayment(paymentId){
  const payment = state.payments.find(p => p.id === paymentId);
  if(!payment || payment.status !== 'pending') return;
  const player = state.players.find(p => p.id === payment.playerId);
  showConfirm(`Approve payment of \u20A6${payment.amount} for ${payment.quantity} ticket(s) from ${player ? player.name : 'this player'}? Their ticket balance will increase automatically.`, () => {
    payment.status = 'confirmed';
    payment.confirmedAt = Date.now();
    if(player){
      player.tickets += payment.quantity;
      if(player.tickets > 0){ player.blocked = false; }
    }
    saveState();
    render();
    showToast('Payment approved — tickets updated');
  });
}

function rejectPayment(paymentId){
  const payment = state.payments.find(p => p.id === paymentId);
  if(!payment || payment.status !== 'pending') return;
  showConfirm('Reject this payment? The ticket balance will not change.', () => {
    payment.status = 'rejected';
    payment.confirmedAt = Date.now();
    saveState();
    render();
    showToast('Payment rejected');
  });
}

// ---- View credit history ----
function openHistoryModal(playerId){
  const player = state.players.find(p => p.id === playerId);
  if(!player) return;
  document.getElementById('history-title').textContent = `${player.name} — Ticket Credit History`;
  const records = state.payments.filter(p => p.playerId === playerId).sort((a,b) => b.createdAt - a.createdAt);
  const listEl = document.getElementById('history-list');
  const balanceHtml = `<div class="history-item"><div><strong>Current balance</strong></div><div>${player.tickets} ticket(s)</div></div>`;
  const recordsHtml = records.length ? records.map(r => `
    <div class="history-item">
      <div>
        ${r.quantity} ticket(s) &middot; \u20A6${r.amount}
        <br><span class="status-badge status-${r.status}">${r.status}</span>
        <span style="color:var(--muted);font-size:11px;margin-left:6px;">${new Date(r.createdAt).toLocaleDateString()}</span>
      </div>
    </div>
  `).join('') : '<div class="empty">No purchase history yet.</div>';
  listEl.innerHTML = balanceHtml + recordsHtml;
  document.getElementById('history-overlay').classList.add('show');
}
document.getElementById('history-close-btn').onclick = () => {
  document.getElementById('history-overlay').classList.remove('show');
};

// ---- Purchase flow (multi-step) ----
function openPurchaseModal(playerId){
  const player = state.players.find(p => p.id === playerId);
  if(!player) return;
  purchaseState = { playerId, quantity: 1, amount: PRICE_PER_TICKET, proofDataUrl: null, step: 1 };
  renderPurchaseStep();
  document.getElementById('purchase-overlay').classList.add('show');
}
function closePurchaseModal(){
  document.getElementById('purchase-overlay').classList.remove('show');
  purchaseState = null;
}

function renderPurchaseStep(){
  if(!purchaseState) return;
  const player = state.players.find(p => p.id === purchaseState.playerId);
  const content = document.getElementById('purchase-step-content');
  const actions = document.getElementById('purchase-actions');
  if(!player){ closePurchaseModal(); return; }

  if(purchaseState.step === 1){
    content.innerHTML = `
      <p style="font-weight:600;margin-bottom:10px;">Buy tickets for ${escapeHtml(player.name)}</p>
      <p style="font-size:13px;color:var(--muted);margin-bottom:10px;">\u20A6${PRICE_PER_TICKET} per ticket.</p>
      <div class="field">
        <label for="purchase-qty-input">Number of tickets</label>
        <input id="purchase-qty-input" type="number" min="1" max="99" value="${purchaseState.quantity}" />
      </div>
    `;
    actions.innerHTML = `
      <button class="btn-ghost" id="purchase-cancel-btn">Cancel</button>
      <button class="btn-amber" id="purchase-next-btn">Confirm</button>
    `;
    document.getElementById('purchase-cancel-btn').onclick = closePurchaseModal;
    document.getElementById('purchase-next-btn').onclick = () => {
      const qtyInput = document.getElementById('purchase-qty-input');
      const qty = parseInt(qtyInput.value, 10);
      if(isNaN(qty) || qty < 1){ showToast('Enter a valid number of tickets'); return; }
      purchaseState.quantity = qty;
      purchaseState.amount = qty * PRICE_PER_TICKET;
      purchaseState.step = 2;
      renderPurchaseStep();
    };
  }

  else if(purchaseState.step === 2){
    content.innerHTML = `
      <p style="font-weight:600;margin-bottom:10px;">Confirm amount</p>
      <p style="font-size:14px;">You're purchasing <strong>${purchaseState.quantity}</strong> ticket(s).</p>
      <p style="font-size:20px;font-weight:700;margin-top:8px;">Amount to pay: \u20A6${purchaseState.amount}</p>
    `;
    actions.innerHTML = `
      <button class="btn-ghost" id="purchase-back-btn">Back</button>
      <button class="btn-amber" id="purchase-makepayment-btn">Make Payment</button>
    `;
    document.getElementById('purchase-back-btn').onclick = () => { purchaseState.step = 1; renderPurchaseStep(); };
    document.getElementById('purchase-makepayment-btn').onclick = () => { purchaseState.step = 3; renderPurchaseStep(); };
  }

  else if(purchaseState.step === 3){
    content.innerHTML = `
      <p style="font-weight:600;margin-bottom:6px;">Make payment</p>
      <p style="font-size:13px;color:var(--muted);">Pay the exact amount below, then tap "I've made payment".</p>
      <div class="account-box">
        <div class="label">Amount</div>
        <div class="value">\u20A6${purchaseState.amount}</div>
        <div class="label" style="margin-top:8px;">Account Number</div>
        <div class="value">${PAYMENT_ACCOUNT.number}</div>
        <div class="label" style="margin-top:8px;">Provider</div>
        <div class="value">${escapeHtml(PAYMENT_ACCOUNT.provider)}</div>
        <div class="label" style="margin-top:8px;">Account Name</div>
        <div class="value">${escapeHtml(PAYMENT_ACCOUNT.name)}</div>
      </div>
    `;
    actions.innerHTML = `
      <button class="btn-ghost" id="purchase-back-btn">Back</button>
      <button class="btn-amber" id="purchase-made-btn">I've made payment</button>
    `;
    document.getElementById('purchase-back-btn').onclick = () => { purchaseState.step = 2; renderPurchaseStep(); };
    document.getElementById('purchase-made-btn').onclick = () => { purchaseState.step = 4; renderPurchaseStep(); };
  }

  else if(purchaseState.step === 4){
    content.innerHTML = `
      <p style="font-weight:600;margin-bottom:6px;">Upload payment proof</p>
      <p style="font-size:13px;color:var(--muted);margin-bottom:10px;">Attach a screenshot or photo of your payment, then tap Confirm.</p>
      <input id="purchase-proof-input" type="file" accept="image/*" />
      <div id="purchase-proof-preview" style="margin-top:10px;"></div>
    `;
    actions.innerHTML = `
      <button class="btn-ghost" id="purchase-back-btn">Back</button>
      <button class="btn-amber" id="purchase-confirm-btn">Confirm</button>
    `;
    document.getElementById('purchase-back-btn').onclick = () => { purchaseState.step = 3; renderPurchaseStep(); };
    document.getElementById('purchase-proof-input').onchange = (e) => {
      const file = e.target.files[0];
      if(!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        purchaseState.proofDataUrl = reader.result;
        document.getElementById('purchase-proof-preview').innerHTML =
          `<img src="${reader.result}" alt="proof preview" style="width:90px;height:90px;object-fit:cover;border-radius:6px;border:1px solid var(--line);" />`;
      };
      reader.readAsDataURL(file);
    };
    document.getElementById('purchase-confirm-btn').onclick = () => {
      if(!purchaseState.proofDataUrl){
        showToast('Please attach your payment proof first');
        return;
      }
      const payment = {
        id: uid(),
        playerId: purchaseState.playerId,
        quantity: purchaseState.quantity,
        amount: purchaseState.amount,
        proofDataUrl: purchaseState.proofDataUrl,
        status: 'pending',
        createdAt: Date.now()
      };
      state.payments.push(payment);
      saveState();
      closePurchaseModal();
      render();
      showToast('Payment submitted — awaiting admin confirmation');
    };
  }
}

// ---- Export / Import code ----
function encodeState(){
  const payload = {
    players: state.players,
    assignments: state.assignments,
    settings: state.settings,
    drawConfirmed: state.drawConfirmed,
    payments: state.payments
  };
  return btoa(unescape(encodeURIComponent(JSON.stringify(payload))));
}

function openExportModal(){
  const code = encodeState();
  document.getElementById('data-modal-title').textContent =
    'Copy this code. Paste it into "Import code" on any other device or browser to load these exact players, tickets, sets, and payment records.';
  const ta = document.getElementById('data-textarea');
  ta.value = code;
  ta.readOnly = true;
  const actionBtn = document.getElementById('data-action-btn');
  actionBtn.textContent = 'Copy';
  actionBtn.onclick = async () => {
    ta.focus();
    ta.select();
    try{
      await navigator.clipboard.writeText(code);
      showToast('Code copied — paste it on the other device');
    }catch(e){
      showToast("Couldn't auto-copy — the text is selected, copy it manually");
    }
  };
  document.getElementById('data-overlay').classList.add('show');
}

function openImportModal(){
  document.getElementById('data-modal-title').textContent =
    'Paste a previously exported code below, then tap Load.';
  const ta = document.getElementById('data-textarea');
  ta.value = '';
  ta.readOnly = false;
  const actionBtn = document.getElementById('data-action-btn');
  actionBtn.textContent = 'Load';
  actionBtn.onclick = () => {
    const code = ta.value.trim();
    if(!code){ showToast('Paste a code first'); return; }
    try{
      const parsed = JSON.parse(decodeURIComponent(escape(atob(code))));
      applyLoadedState(parsed);
      document.getElementById('data-overlay').classList.remove('show');
      render();
      saveState();
      showToast('Players loaded from code');
    }catch(e){
      showToast('That code looks invalid — check it and try again');
    }
  };
  document.getElementById('data-overlay').classList.add('show');
}

document.getElementById('export-btn').onclick = openExportModal;
document.getElementById('import-btn').onclick = openImportModal;
document.getElementById('data-cancel-btn').onclick = () => {
  document.getElementById('data-overlay').classList.remove('show');
};

function openCopyNamesModal(){
  const names = state.players
    .map(p => `${p.name} (${p.role === 'defend' ? 'Defend' : 'Forward'})`)
    .join('\n');
  document.getElementById('data-modal-title').textContent =
    'All registered player names — select the text or tap Copy.';
  const ta = document.getElementById('data-textarea');
  ta.value = names || 'No players registered yet.';
  ta.readOnly = true;
  const actionBtn = document.getElementById('data-action-btn');
  actionBtn.textContent = 'Copy';
  actionBtn.onclick = async () => {
    ta.focus();
    ta.select();
    try{
      await navigator.clipboard.writeText(names);
      showToast('Names copied to clipboard');
    }catch(e){
      showToast("Couldn't auto-copy — the text is selected, copy it manually");
    }
  };
  document.getElementById('data-overlay').classList.add('show');
}
document.getElementById('copy-names-btn').onclick = openCopyNamesModal;

loadState();
