CREATE TABLE "admins" (
	"id" serial PRIMARY KEY,
	"username" text NOT NULL UNIQUE,
	"password_hash" text NOT NULL,
	"failed_logins" integer DEFAULT 0 NOT NULL,
	"locked_until" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "app_state" (
	"id" integer PRIMARY KEY,
	"account_number" text NOT NULL,
	"bank_name" text NOT NULL,
	"account_name" text NOT NULL,
	"num_sets" integer DEFAULT 4 NOT NULL,
	"players_per_set" integer DEFAULT 6 NOT NULL,
	"assignments" jsonb DEFAULT '{}' NOT NULL,
	"draw_confirmed" boolean DEFAULT false NOT NULL,
	"matchday_started_at" timestamp with time zone DEFAULT now() NOT NULL,
	"draw_enabled" boolean DEFAULT false NOT NULL,
	"draw_session_id" integer,
	"draw_enabled_by" integer,
	"draw_enabled_at" timestamp with time zone,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "audit_log" (
	"id" serial PRIMARY KEY,
	"actor_type" text NOT NULL,
	"actor_id" integer,
	"actor_name" text,
	"action" text NOT NULL,
	"target_type" text,
	"target_id" text,
	"details" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "contribution_members" (
	"id" serial PRIMARY KEY,
	"pool_id" integer NOT NULL,
	"player_id" integer NOT NULL,
	"status" text DEFAULT 'not_paid' NOT NULL,
	"amount_contributed" integer,
	"paid_date" text,
	"note" text,
	"proof_id" integer,
	"submitted_at" timestamp with time zone,
	"reviewed_by" integer,
	"reviewed_by_name" text,
	"reviewed_at" timestamp with time zone,
	"rejection_reason" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "contribution_pools" (
	"id" serial PRIMARY KEY,
	"title" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"type" text NOT NULL,
	"amount_per_player" integer,
	"other_requirement" text,
	"start_date" timestamp with time zone,
	"deadline" timestamp with time zone,
	"account_number" text,
	"bank_name" text,
	"account_name" text,
	"instructions" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'draft' NOT NULL,
	"created_by" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "draw_events" (
	"id" serial PRIMARY KEY,
	"type" text NOT NULL,
	"actor_type" text NOT NULL,
	"actor_id" integer,
	"actor_name" text,
	"details" jsonb DEFAULT '{}' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"id" serial PRIMARY KEY,
	"player_id" integer NOT NULL,
	"message" text NOT NULL,
	"read_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "players" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"name_key" text NOT NULL,
	"role" text DEFAULT 'forward' NOT NULL,
	"pin_hash" text NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"status_reason" text,
	"status_changed_at" timestamp with time zone,
	"ticket_balance" integer DEFAULT 0 NOT NULL,
	"present" boolean DEFAULT false NOT NULL,
	"failed_logins" integer DEFAULT 0 NOT NULL,
	"locked_until" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "proof_files" (
	"id" serial PRIMARY KEY,
	"player_id" integer NOT NULL,
	"owner_type" text NOT NULL,
	"owner_id" integer NOT NULL,
	"blob_key" text NOT NULL UNIQUE,
	"mime_type" text NOT NULL,
	"file_name" text NOT NULL,
	"size_bytes" integer NOT NULL,
	"uploaded_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"id" serial PRIMARY KEY,
	"token_hash" text NOT NULL UNIQUE,
	"kind" text NOT NULL,
	"subject_id" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"revoked_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "ticket_ledger" (
	"id" serial PRIMARY KEY,
	"player_id" integer NOT NULL,
	"type" text NOT NULL,
	"delta" integer NOT NULL,
	"balance_before" integer NOT NULL,
	"balance_after" integer NOT NULL,
	"reference" text NOT NULL,
	"order_id" integer UNIQUE,
	"amount" integer,
	"admin_id" integer,
	"admin_name" text,
	"reason" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "ticket_orders" (
	"id" serial PRIMARY KEY,
	"reference" text NOT NULL UNIQUE,
	"player_id" integer NOT NULL,
	"quantity" integer NOT NULL,
	"unit_price" integer NOT NULL,
	"amount" integer NOT NULL,
	"status" text DEFAULT 'awaiting_payment' NOT NULL,
	"account_number" text NOT NULL,
	"bank_name" text NOT NULL,
	"account_name" text NOT NULL,
	"proof_id" integer,
	"payment_date" text,
	"submitted_at" timestamp with time zone,
	"review_started_at" timestamp with time zone,
	"reviewed_by" integer,
	"reviewed_by_name" text,
	"reviewed_at" timestamp with time zone,
	"rejection_reason" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "contribution_members_pool_player_idx" ON "contribution_members" ("pool_id","player_id");--> statement-breakpoint
CREATE INDEX "notifications_player_idx" ON "notifications" ("player_id");--> statement-breakpoint
CREATE UNIQUE INDEX "players_name_key_idx" ON "players" ("name_key");--> statement-breakpoint
CREATE INDEX "proof_files_owner_idx" ON "proof_files" ("owner_type","owner_id");--> statement-breakpoint
CREATE INDEX "sessions_subject_idx" ON "sessions" ("kind","subject_id");--> statement-breakpoint
CREATE INDEX "ticket_ledger_player_idx" ON "ticket_ledger" ("player_id");--> statement-breakpoint
CREATE INDEX "ticket_orders_player_idx" ON "ticket_orders" ("player_id");--> statement-breakpoint
CREATE INDEX "ticket_orders_status_idx" ON "ticket_orders" ("status");--> statement-breakpoint
ALTER TABLE "contribution_members" ADD CONSTRAINT "contribution_members_pool_id_contribution_pools_id_fkey" FOREIGN KEY ("pool_id") REFERENCES "contribution_pools"("id");--> statement-breakpoint
ALTER TABLE "contribution_members" ADD CONSTRAINT "contribution_members_player_id_players_id_fkey" FOREIGN KEY ("player_id") REFERENCES "players"("id");--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_player_id_players_id_fkey" FOREIGN KEY ("player_id") REFERENCES "players"("id");--> statement-breakpoint
ALTER TABLE "proof_files" ADD CONSTRAINT "proof_files_player_id_players_id_fkey" FOREIGN KEY ("player_id") REFERENCES "players"("id");--> statement-breakpoint
ALTER TABLE "ticket_ledger" ADD CONSTRAINT "ticket_ledger_player_id_players_id_fkey" FOREIGN KEY ("player_id") REFERENCES "players"("id");--> statement-breakpoint
ALTER TABLE "ticket_orders" ADD CONSTRAINT "ticket_orders_player_id_players_id_fkey" FOREIGN KEY ("player_id") REFERENCES "players"("id");