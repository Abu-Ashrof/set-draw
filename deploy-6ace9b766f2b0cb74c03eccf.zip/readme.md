# Matchday Set Draw — Standalone Site

This is a plain HTML/CSS/JavaScript version of your Claude Artifact, split
into three files so it can be hosted anywhere, including Netlify, with no
build step and no framework required.

## Files in this project

```
.
├── index.html      Page structure (all sections, forms, modals)
├── style.css        All styling (colors, layout, responsive rules)
├── script.js         All app logic (players, draw, tickets, payments, admin)
└── netlify.toml      Optional Netlify config (static hosting + basic security headers)
```

Everything from the original artifact is preserved as-is: the settings
panel, player list with search, presence toggles, role-balanced sequential
draw, sets grid with the deal-in animation, draw confirmation flow, ticket
purchase flow (quantity → amount → payment instructions → proof upload),
admin passcode gate with ticket editing and payment approval/rejection,
export/import codes, and the "Copy names" list. The layout is responsive
exactly as before (the sets grid drops from two columns to one under
560px, and the rest uses fluid widths/clamp() sizing), so it will work the
same on phones and desktops.

## How data is stored

- **Local only, by default:** the app saves everything to the browser's
  `localStorage`. Each visitor's browser keeps its own copy. This works
  immediately with zero setup.
- **Optional shared sync:** the code also supports a shared, real-time
  data store via Firebase Realtime Database, so every device sees the
  same players/sets/payments automatically. This is **off by default** —
  see "Optional: turn on shared sync" below.

## Important security note (please read)

Two things in `script.js` are visible to anyone who views the page
source, because this is a pure front-end app with no server:

1. **`ADMIN_PASSCODE`** (currently `'admin123'`) — this only gates the UI
   in the visitor's own browser. It is **not real authentication**. Anyone
   who opens the browser's developer tools can read it directly from the
   script file, regardless of what you set it to. Treat "Admin mode" as a
   convenience toggle for trusted users, not a security boundary. If you
   need real access control (e.g., to protect payment approvals), you'd
   need a backend/auth system, which is outside the scope of a static
   Netlify site. At minimum, change this value to something only your
   group knows before you deploy, by editing the line near the top of
   `script.js`:
   ```js
   const ADMIN_PASSCODE = 'admin123'; // change this
   ```
2. **The Firebase config block** (`firebaseConfig` in `script.js`) is
   fine to leave in the front-end code if you do set it up — Firebase
   web config values are designed to be public; they identify your
   project but don't themselves grant access. Access is controlled by
   your Firebase **Realtime Database security rules**, which you set in
   the Firebase console, not in this file. No other API keys, passwords,
   or secret credentials are present anywhere in this project.

## Deploying to Netlify

You have two easy options.

### Option A — Drag and drop (fastest, no account linking)

1. Go to [app.netlify.com](https://app.netlify.com) and log in (or create
   a free account).
2. On your dashboard, go to **Sites** and look for the drag-and-drop area
   (usually says "Drag and drop your site output folder here" / "Deploys").
3. Drag the whole project folder (the folder containing `index.html`,
   `style.css`, `script.js`, `netlify.toml`) onto that area.
4. Netlify uploads the files and gives you a live URL like
   `https://random-name-123.netlify.app` within seconds.
5. Optional: in **Site settings → Change site name**, pick a custom
   subdomain, or connect a custom domain under **Domain settings**.

No build command or publish directory settings are needed — this is a
static site, so what you upload is exactly what gets served.

### Option B — Connect a Git repository (recommended if you'll keep editing)

1. Create a new repository (GitHub, GitLab, or Bitbucket) and push these
   project files to it:
   ```bash
   cd matchday-set-draw
   git init
   git add .
   git commit -m "Initial commit — Matchday Set Draw static site"
   git branch -M main
   git remote add origin <your-repo-url>
   git push -u origin main
   ```
2. In Netlify, click **Add new site → Import an existing project**.
3. Pick your Git provider and select the repository.
4. Build settings:
   - **Build command:** leave blank (no build step needed)
   - **Publish directory:** `.` (the repository root, since `index.html`
     lives at the top level)
5. Click **Deploy site**. Netlify will redeploy automatically every time
   you push changes to the repository.

Either way, `netlify.toml` already tells Netlify to publish the root
folder and adds a few standard security headers — you don't need to set
anything manually in the UI.

## Optional: turn on shared sync across devices

By default every browser only sees its own local data. If you want
everyone who opens the site to see the same players, sets, and payment
requests in real time:

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
   and create a free project.
2. In the project, go to **Build → Realtime Database → Create Database**
   (choose any region; start in test mode to begin, then lock it down —
   see note below).
3. Go to **Project settings → General**, scroll to "Your apps", click the
   web icon (`</>`) to register a web app, and copy the config object it
   gives you.
4. Open `script.js` and paste your values into the `firebaseConfig`
   object near the top:
   ```js
   const firebaseConfig = {
     apiKey: "your-actual-api-key",
     authDomain: "your-project.firebaseapp.com",
     databaseURL: "https://your-project-default-rtdb.firebaseio.com",
     projectId: "your-project-id"
   };
   ```
5. Redeploy (drag-and-drop the updated folder again, or push the commit
   if you used Git).
6. **Before sharing the link publicly**, go to your Realtime Database's
   **Rules** tab in the Firebase console and replace the default
   test-mode rules (which allow anyone to read/write) with rules scoped
   to your use case — for example, requiring Firebase Authentication, or
   at least setting an expiry date on open test-mode rules. Test mode is
   meant for development only.

If you skip this section entirely, the app still works fully — it just
won't sync between different browsers/devices.

## Local preview before deploying

You can open `index.html` directly in a browser, or serve it locally:

```bash
cd matchday-set-draw
python3 -m http.server 8000
# then visit http://localhost:8000
```

Both work; a local server is only needed if you run into browser
restrictions around `localStorage` with the `file://` protocol in some
browsers.
