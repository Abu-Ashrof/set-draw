import {
  pgTable,
  serial,
  text,
  timestamp,
  integer,
  boolean,
  jsonb,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

// ---- Accounts ----

export const admins = pgTable("admins", {
  id: serial().primaryKey(),
  username: text().notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  failedLogins: integer("failed_logins").notNull().default(0),
  lockedUntil: timestamp("locked_until", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const players = pgTable(
  "players",
  {
    id: serial().primaryKey(),
    name: text().notNull(),
    nameKey: text("name_key").notNull(),
    role: text().notNull().default("forward"), // forward | defend
    pinHash: text("pin_hash").notNull(),
    // active | suspended | disabled
    status: text().notNull().default("active"),
    statusReason: text("status_reason"),
    statusChangedAt: timestamp("status_changed_at", { withTimezone: true }),
    // Only ever changed inside a DB transaction together with a ticket_ledger row.
    ticketBalance: integer("ticket_balance").notNull().default(0),
    present: boolean().notNull().default(false),
    failedLogins: integer("failed_logins").notNull().default(0),
    lockedUntil: timestamp("locked_until", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("players_name_key_idx").on(t.nameKey)],
);

// Server-side sessions. The browser only holds an opaque random token in an
// HttpOnly cookie; we store its SHA-256 hash here.
export const sessions = pgTable(
  "sessions",
  {
    id: serial().primaryKey(),
    tokenHash: text("token_hash").notNull().unique(),
    kind: text().notNull(), // admin | player
    subjectId: integer("subject_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
  },
  (t) => [index("sessions_subject_idx").on(t.kind, t.subjectId)],
);

// ---- Global settings / matchday state (single row, id = 1) ----

export const appState = pgTable("app_state", {
  id: integer().primaryKey(),
  accountNumber: text("account_number").notNull(),
  bankName: text("bank_name").notNull(),
  accountName: text("account_name").notNull(),
  numSets: integer("num_sets").notNull().default(4),
  playersPerSet: integer("players_per_set").notNull().default(6),
  assignments: jsonb().$type<Record<string, number[]>>().notNull().default({}),
  drawConfirmed: boolean("draw_confirmed").notNull().default(false),
  matchdayStartedAt: timestamp("matchday_started_at", { withTimezone: true }).notNull().defaultNow(),
  // Draw permission is bound to the admin session that enabled it. It is only
  // valid while that exact session exists, is not revoked and has not expired.
  drawEnabled: boolean("draw_enabled").notNull().default(false),
  drawSessionId: integer("draw_session_id"),
  drawEnabledBy: integer("draw_enabled_by"),
  drawEnabledAt: timestamp("draw_enabled_at", { withTimezone: true }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

// ---- Uploaded proof files (binary content lives in Netlify Blobs) ----

export const proofFiles = pgTable(
  "proof_files",
  {
    id: serial().primaryKey(),
    playerId: integer("player_id").notNull().references(() => players.id),
    ownerType: text("owner_type").notNull(), // ticket_order | contribution
    ownerId: integer("owner_id").notNull(),
    blobKey: text("blob_key").notNull().unique(),
    mimeType: text("mime_type").notNull(),
    fileName: text("file_name").notNull(),
    sizeBytes: integer("size_bytes").notNull(),
    uploadedAt: timestamp("uploaded_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("proof_files_owner_idx").on(t.ownerType, t.ownerId)],
);

// ---- Ticket orders ----

export const ticketOrders = pgTable(
  "ticket_orders",
  {
    id: serial().primaryKey(),
    reference: text().notNull().unique(),
    playerId: integer("player_id").notNull().references(() => players.id),
    quantity: integer().notNull(),
    unitPrice: integer("unit_price").notNull(),
    amount: integer().notNull(),
    // awaiting_payment | proof_submitted | under_review | approved | rejected | cancelled
    status: text().notNull().default("awaiting_payment"),
    accountNumber: text("account_number").notNull(),
    bankName: text("bank_name").notNull(),
    accountName: text("account_name").notNull(),
    proofId: integer("proof_id"),
    paymentDate: text("payment_date"),
    submittedAt: timestamp("submitted_at", { withTimezone: true }),
    reviewStartedAt: timestamp("review_started_at", { withTimezone: true }),
    reviewedBy: integer("reviewed_by"),
    reviewedByName: text("reviewed_by_name"),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
    rejectionReason: text("rejection_reason"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("ticket_orders_player_idx").on(t.playerId), index("ticket_orders_status_idx").on(t.status)],
);

// Permanent, append-only ticket ledger. players.ticket_balance always equals the
// sum of delta for that player.
export const ticketLedger = pgTable(
  "ticket_ledger",
  {
    id: serial().primaryKey(),
    playerId: integer("player_id").notNull().references(() => players.id),
    type: text().notNull(), // purchase | draw | adjustment
    delta: integer().notNull(),
    balanceBefore: integer("balance_before").notNull(),
    balanceAfter: integer("balance_after").notNull(),
    reference: text().notNull(),
    // Unique: one ticket order can never be credited twice.
    orderId: integer("order_id").unique(),
    amount: integer(),
    adminId: integer("admin_id"),
    adminName: text("admin_name"),
    reason: text(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("ticket_ledger_player_idx").on(t.playerId)],
);

// ---- Contributions ----

export const contributionPools = pgTable("contribution_pools", {
  id: serial().primaryKey(),
  title: text().notNull(),
  description: text().notNull().default(""),
  type: text().notNull(), // money | other
  amountPerPlayer: integer("amount_per_player"),
  otherRequirement: text("other_requirement"),
  startDate: timestamp("start_date", { withTimezone: true }),
  deadline: timestamp({ withTimezone: true }),
  accountNumber: text("account_number"),
  bankName: text("bank_name"),
  accountName: text("account_name"),
  instructions: text().notNull().default(""),
  status: text().notNull().default("draft"), // draft | open | closed | completed
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const contributionMembers = pgTable(
  "contribution_members",
  {
    id: serial().primaryKey(),
    poolId: integer("pool_id").notNull().references(() => contributionPools.id),
    playerId: integer("player_id").notNull().references(() => players.id),
    // not_paid | pending_verification | confirmed | rejected
    status: text().notNull().default("not_paid"),
    amountContributed: integer("amount_contributed"),
    paidDate: text("paid_date"),
    note: text(),
    proofId: integer("proof_id"),
    submittedAt: timestamp("submitted_at", { withTimezone: true }),
    reviewedBy: integer("reviewed_by"),
    reviewedByName: text("reviewed_by_name"),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
    rejectionReason: text("rejection_reason"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("contribution_members_pool_player_idx").on(t.poolId, t.playerId)],
);

// ---- Notifications, draw history, audit log ----

export const notifications = pgTable(
  "notifications",
  {
    id: serial().primaryKey(),
    playerId: integer("player_id").notNull().references(() => players.id),
    message: text().notNull(),
    readAt: timestamp("read_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("notifications_player_idx").on(t.playerId)],
);

export const drawEvents = pgTable("draw_events", {
  id: serial().primaryKey(),
  type: text().notNull(), // run | reset | confirm | new_matchday | denied
  actorType: text("actor_type").notNull(), // admin | player
  actorId: integer("actor_id"),
  actorName: text("actor_name"),
  details: jsonb().$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const auditLog = pgTable("audit_log", {
  id: serial().primaryKey(),
  actorType: text("actor_type").notNull(), // admin | player | system
  actorId: integer("actor_id"),
  actorName: text("actor_name"),
  action: text().notNull(),
  targetType: text("target_type"),
  targetId: text("target_id"),
  details: jsonb().$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
